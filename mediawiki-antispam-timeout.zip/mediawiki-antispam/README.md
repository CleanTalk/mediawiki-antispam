mediawiki-antispam
==================

Antispam extension for MediaWiki.
